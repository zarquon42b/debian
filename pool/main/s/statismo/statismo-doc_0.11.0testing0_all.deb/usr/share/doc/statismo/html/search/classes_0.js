var searchData=
[
  ['builderinfo',['BuilderInfo',['../classstatismo_1_1BuilderInfo.html',1,'statismo']]]
];

var searchData=
[
  ['interpolatingstatisticaldeformationmodeltransform',['InterpolatingStatisticalDeformationModelTransform',['../classitk_1_1InterpolatingStatisticalDeformationModelTransform.html',1,'itk']]]
];

var searchData=
[
  ['uncorrelatedmatrixvaluedkernel',['UncorrelatedMatrixValuedKernel',['../classstatismo_1_1UncorrelatedMatrixValuedKernel.html',1,'statismo']]]
];

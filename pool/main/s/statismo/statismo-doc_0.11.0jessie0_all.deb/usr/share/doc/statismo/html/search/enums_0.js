var searchData=
[
  ['eigenvaluemethod',['EigenValueMethod',['../classstatismo_1_1PCAModelBuilder.html#ac38f94532939d8525a95089131b62d58',1,'statismo::PCAModelBuilder']]]
];

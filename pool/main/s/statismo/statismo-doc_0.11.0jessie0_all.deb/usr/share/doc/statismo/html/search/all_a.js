var searchData=
[
  ['notimplementedexception',['NotImplementedException',['../classstatismo_1_1NotImplementedException.html',1,'statismo']]],
  ['nystrom',['Nystrom',['../classstatismo_1_1Nystrom.html',1,'statismo']]]
];

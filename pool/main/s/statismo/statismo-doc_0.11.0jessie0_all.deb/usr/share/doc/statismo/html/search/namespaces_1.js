var searchData=
[
  ['statismo',['statismo',['../namespacestatismo.html',1,'']]]
];

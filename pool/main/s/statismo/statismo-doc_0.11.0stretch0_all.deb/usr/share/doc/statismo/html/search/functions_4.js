var searchData=
[
  ['evaluatesampleatpoint',['EvaluateSampleAtPoint',['../classstatismo_1_1StatisticalModel.html#a19fe088dd03bdf1513b1ef5744cccc8b',1,'statismo::StatisticalModel::EvaluateSampleAtPoint(DatasetConstPointerType sample, unsigned ptId) const '],['../classstatismo_1_1StatisticalModel.html#a3b0d505d8c46b7400849e20f7d727068',1,'statismo::StatisticalModel::EvaluateSampleAtPoint(DatasetConstPointerType sample, const PointType &amp;pt) const ']]],
  ['existsobjectwithname',['existsObjectWithName',['../classstatismo_1_1HDF5Utils.html#a85ad7f1b807784509de0908e54851d9f',1,'statismo::HDF5Utils']]]
];

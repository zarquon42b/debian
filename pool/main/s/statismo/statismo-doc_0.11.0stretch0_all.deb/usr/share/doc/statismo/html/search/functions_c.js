var searchData=
[
  ['sampletosamplevector',['SampleToSampleVector',['../classitk_1_1StandardMeshRepresenter.html#a4bfdd14a628f58b62641ad588f7bd42f',1,'itk::StandardMeshRepresenter']]],
  ['samplevectortosample',['SampleVectorToSample',['../classitk_1_1StandardMeshRepresenter.html#a727124644e8ed88160a7fe604a01b231',1,'itk::StandardMeshRepresenter']]],
  ['save',['Save',['../classstatismo_1_1DataManager.html#a3aff587cb3c3fe9c3481d4697c57cd4e',1,'statismo::DataManager::Save()'],['../classstatismo_1_1ModelInfo.html#a1d10688356271f240c93e2a4bd8d2ebe',1,'statismo::ModelInfo::Save()'],['../classstatismo_1_1BuilderInfo.html#a132862d5008a7db2f0bcd3095552c6f8',1,'statismo::BuilderInfo::Save()'],['../classstatismo_1_1StatisticalModel.html#ab87f2711638ad8161525ba83b4b41a96',1,'statismo::StatisticalModel::Save(const std::string &amp;filename) const '],['../classstatismo_1_1StatisticalModel.html#ac1185df13b7b0352973887462720eda3',1,'statismo::StatisticalModel::Save(const H5::Group &amp;modelRoot) const '],['../classitk_1_1StandardMeshRepresenter.html#ab87098212639f355db128aec8cfa752f',1,'itk::StandardMeshRepresenter::Save()']]],
  ['scalarvaluedkernel',['ScalarValuedKernel',['../classstatismo_1_1ScalarValuedKernel.html#a8db80a0013b3e55f1909bfb0ba91fe43',1,'statismo::ScalarValuedKernel']]],
  ['setcoefficients',['SetCoefficients',['../classitk_1_1StatisticalModelTransformBase.html#ad0ba1985985fcee53e0db8ed22d95d61',1,'itk::StatisticalModelTransformBase']]],
  ['setfixedparameters',['SetFixedParameters',['../classitk_1_1StatisticalModelTransformBase.html#a124b5e372d48d08d3a3da678da766313',1,'itk::StatisticalModelTransformBase']]],
  ['setidentity',['SetIdentity',['../classitk_1_1StatisticalModelTransformBase.html#a9f1dcd1ad9a8bf579716e79da15c24ca',1,'itk::StatisticalModelTransformBase']]],
  ['setmodelinfo',['SetModelInfo',['../classstatismo_1_1StatisticalModel.html#ae66c6dd4560119862ae5f524bf92d467',1,'statismo::StatisticalModel']]],
  ['setparameters',['SetParameters',['../classitk_1_1StatisticalModelTransformBase.html#a69cf04457ccb5b156ccdb3edc10b314f',1,'itk::StatisticalModelTransformBase']]],
  ['setreference',['SetReference',['../classitk_1_1StandardImageRepresenter.html#a659d0e466c9223c5c448c05cdf2a5fff',1,'itk::StandardImageRepresenter::SetReference()'],['../classitk_1_1StandardMeshRepresenter.html#a82ab5eff60044305d89cf8735683f016',1,'itk::StandardMeshRepresenter::SetReference()']]],
  ['setstatisticalmodel',['SetStatisticalModel',['../classitk_1_1StatisticalModelTransformBase.html#a72009bbb50ed0573892e7aaf34f30fb5',1,'itk::StatisticalModelTransformBase']]],
  ['setusednumberofcoefficients',['SetUsedNumberOfCoefficients',['../classitk_1_1StatisticalModelTransformBase.html#a984b8f3692442bd519f6e0e70073952e',1,'itk::StatisticalModelTransformBase']]],
  ['spatiallyvaryingkernel',['SpatiallyVaryingKernel',['../classstatismo_1_1SpatiallyVaryingKernel.html#a264238bcfeaf5c9ca5b8fc6ed39df469',1,'statismo::SpatiallyVaryingKernel']]],
  ['statisticalmodeltransformbase',['StatisticalModelTransformBase',['../classitk_1_1StatisticalModelTransformBase.html#a80fc992a3256fe40b377ffb0e73a1c99',1,'itk::StatisticalModelTransformBase']]]
];

var searchData=
[
  ['eigenfunctioncomputationresult',['EigenfunctionComputationResult',['../structstatismo_1_1EigenfunctionComputationResult.html',1,'statismo']]],
  ['eigenvaluemethod',['EigenValueMethod',['../classstatismo_1_1PCAModelBuilder.html#ac38f94532939d8525a95089131b62d58',1,'statismo::PCAModelBuilder']]],
  ['evaluatesampleatpoint',['EvaluateSampleAtPoint',['../classstatismo_1_1StatisticalModel.html#a19fe088dd03bdf1513b1ef5744cccc8b',1,'statismo::StatisticalModel::EvaluateSampleAtPoint(DatasetConstPointerType sample, unsigned ptId) const '],['../classstatismo_1_1StatisticalModel.html#a3b0d505d8c46b7400849e20f7d727068',1,'statismo::StatisticalModel::EvaluateSampleAtPoint(DatasetConstPointerType sample, const PointType &amp;pt) const ']]],
  ['existsobjectwithname',['existsObjectWithName',['../classstatismo_1_1HDF5Utils.html#a85ad7f1b807784509de0908e54851d9f',1,'statismo::HDF5Utils']]]
];

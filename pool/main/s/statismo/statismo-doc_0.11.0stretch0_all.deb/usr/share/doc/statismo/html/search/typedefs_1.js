var searchData=
[
  ['scalartype',['ScalarType',['../namespacestatismo.html#a67d036222c0aff83e58ff5e68253139f',1,'statismo']]]
];

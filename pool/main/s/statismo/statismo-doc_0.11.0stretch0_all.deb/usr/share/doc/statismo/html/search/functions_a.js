var searchData=
[
  ['pointsamplefromsample',['PointSampleFromSample',['../classitk_1_1StandardMeshRepresenter.html#a3619ea61db5fac31e57a203b395499c0',1,'itk::StandardMeshRepresenter']]],
  ['pointsampletopointsamplevector',['PointSampleToPointSampleVector',['../classitk_1_1StandardMeshRepresenter.html#af0ed8ac6bb0bbdb62c8ed47c482db3dc',1,'itk::StandardMeshRepresenter']]],
  ['pointsamplevectortopointsample',['PointSampleVectorToPointSample',['../classitk_1_1StandardMeshRepresenter.html#af4f99a7190b4f0a94c9138039f739bdc',1,'itk::StandardMeshRepresenter']]],
  ['pointtovector',['PointToVector',['../classitk_1_1StandardImageRepresenter.html#ab1ba3ad202f4296d37205fc58ee05c27',1,'itk::StandardImageRepresenter']]]
];

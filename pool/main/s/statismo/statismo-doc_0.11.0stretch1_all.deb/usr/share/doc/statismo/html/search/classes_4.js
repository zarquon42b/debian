var searchData=
[
  ['gaussiankernel',['GaussianKernel',['../classGaussianKernel.html',1,'']]],
  ['genericrepresentertest',['GenericRepresenterTest',['../classGenericRepresenterTest.html',1,'']]]
];

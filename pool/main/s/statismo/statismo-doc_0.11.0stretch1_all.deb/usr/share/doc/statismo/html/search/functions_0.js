var searchData=
[
  ['adddataset',['AddDataset',['../classstatismo_1_1DataManager.html#aca7c9c979962f23876331ebf6dcf8cda',1,'statismo::DataManager']]],
  ['adddatasetwithsurrogates',['AddDatasetWithSurrogates',['../classstatismo_1_1DataManagerWithSurrogates.html#a8737fc49cd520303233c2cc35880ef88',1,'statismo::DataManagerWithSurrogates']]]
];

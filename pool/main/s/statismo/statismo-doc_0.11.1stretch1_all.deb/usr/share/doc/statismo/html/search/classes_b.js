var searchData=
[
  ['randsvd',['RandSVD',['../classstatismo_1_1RandSVD.html',1,'statismo']]],
  ['reducedvariancemodelbuilder',['ReducedVarianceModelBuilder',['../classstatismo_1_1ReducedVarianceModelBuilder.html',1,'statismo']]],
  ['reducedvariancemodelbuilder',['ReducedVarianceModelBuilder',['../classitk_1_1ReducedVarianceModelBuilder.html',1,'itk']]]
];
